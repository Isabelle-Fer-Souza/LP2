﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtLadoA.Text, out ladoA))
            {
                errorProvider1.SetError(txtLadoA, "Valor inválido!");
                txtLadoA.Focus();
            }
            else
            {
                errorProvider1.SetError(txtLadoA, "");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB))
            {
                errorProvider1.SetError(txtLadoB, "Valor inválido!");
                txtLadoB.Focus();
            }
            else
            {
                errorProvider1.SetError(txtLadoB, "");
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC))
            {
                errorProvider1.SetError(txtLadoC, "Valor inválido!");
                txtLadoC.Focus();
            }
            else
            {
                errorProvider1.SetError(txtLadoC, "");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if( (ladoA < ladoB+ladoC) && (ladoA > Math.Abs(ladoB-ladoC)) &&
                (ladoB < ladoA+ladoC) && (ladoB > Math.Abs(ladoA-ladoC)) &&
                (ladoC < ladoA+ladoB) && (ladoC > Math.Abs(ladoA-ladoB)) )
            {
                if( (ladoA ==  ladoB) && (ladoB == ladoC) )
                {
                    MessageBox.Show("Esses valores pertencem a um triângulo equilátero.");
                } else if ( (ladoA != ladoB) && ( ladoA != ladoC) && (ladoB != ladoC) )
                {
                    MessageBox.Show("Esses valores pertencem a um triângulo escaleno.");
                } else
                {
                    MessageBox.Show("Esses valores pertencem a um triânculo isósceles.");
                }
            } else
            {
                MessageBox.Show("Esses valores não pertencem aos lados de um triângulo.");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

    }
}
