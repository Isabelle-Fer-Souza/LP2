﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;

            while(contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                {
                    contaNum++;
                }
                contador++;
            }

            MessageBox.Show($"O texto tem {contaNum} números");

        }

        private void btnPosicaoCaracter_Click(object sender, EventArgs e)
        {
            int qntdCaracterBranco = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if(char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do primeiro caracter branco é {i+1}");
                    qntdCaracterBranco++;
                    break;
                }
            }
            if (qntdCaracterBranco == 0)
            {
                MessageBox.Show("Não há caracter branco no texto!");
            }
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach(char c in rchtxtFrase.Text)
            {
                if(char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"Há {contaLetra} letras no texto.");
        }

        private void rchtxtFrase_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
