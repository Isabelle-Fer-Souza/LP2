﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotebook01
{
    public partial class frm1 : Form
    {
        public frm1()
        {
            InitializeComponent();
        }


        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] valoresNotebook = new double[3, 3];
            string auxiliar = "";
            string saida = "";
            double [] mediaLojas = new double[3];
            double mediaGeral = 0;

            for (int m = 0; m < 3; m++)
            {
                for (int l = 0; l < 3; l++)
                {
                    auxiliar = Interaction.InputBox($"Digite o valor do modelo {m+1} da loja {l+1}", "Entrada de Dados");
                    if(!(Double.TryParse(auxiliar, out valoresNotebook[m, l])) || valoresNotebook[m, l] < 0) {
                        MessageBox.Show("Dados Inválidos!");
                        l--;
                    } else
                    {
                        mediaGeral += valoresNotebook[m, l];
                        mediaLojas[m] += valoresNotebook[m, l];
                        if(l == 0)
                        {
                            saida += $"Notebook: {m+1}  Loja {l+1}: {valoresNotebook[m,l].ToString("C2")}  ";
                        } else
                        {
                            saida += $"Loja {l+1}: {valoresNotebook[m, l].ToString("C2")}  ";
                        }
                    }
                }

                mediaLojas[m] = mediaLojas[m] / 3;
                saida += $"Média: { String.Format("{0:C2}",mediaLojas[m]) }";
                lstbxValores.Items.Add(saida);
                saida = "";
            }
            mediaGeral = mediaGeral / 9;
            lstbxValores.Items.Add("---------------------");
            lstbxValores.Items.Add($"Média Geral Domputadores: {mediaGeral.ToString("C2")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxValores.Items.Clear();
        }
    }
}
