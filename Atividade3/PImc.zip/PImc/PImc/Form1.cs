﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void msktxtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(msktxtPeso.Text, out peso) || peso == 0)
            {
                errorProvider1.SetError(msktxtPeso, "Peso inválido!"); //Componento que cria um símbolo vermelho de erro no componente e ao passar o mouse por cima exibe a mensagem
                msktxtPeso.Focus(); // Obriga o usuário a voltar ao txtNumero1
            }
            else
            {
                errorProvider1.SetError(msktxtPeso, ""); // Limpar o erro provider para não ficar aparecendo o erro quando der certo
            }
        }

        private void msktxtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(msktxtAltura.Text, out altura) || altura == 0)
            {
                errorProvider1.SetError(msktxtAltura, "Altura inválida!"); //Componento que cria um símbolo vermelho de erro no componente e ao passar o mouse por cima exibe a mensagem
                msktxtAltura.Focus(); // Obriga o usuário a voltar ao txtNumero1
            }
            else
            {
                errorProvider1.SetError(msktxtAltura, ""); // Limpar o erro provider para não ficar aparecendo o erro quando der certo
            }
        }



        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            txtIMC.Text = imc.ToString("N1");

            if(imc < 18.5) {
                txtClassificacao.Text = "Magreza";
            } else if (imc <= 24.9) {
                txtClassificacao.Text = "Normal";
            } else if (imc <= 29.9)
            {
                txtClassificacao.Text = "Sobrepeso";
            } else if (imc <= 39.9)
            {
                txtClassificacao.Text = "Obesidade";
            } else
            {
                txtClassificacao.Text = "Obesidade Grave";
            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            msktxtAltura.Clear();
            msktxtPeso.Clear();
            txtIMC.Clear();
            txtClassificacao.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
