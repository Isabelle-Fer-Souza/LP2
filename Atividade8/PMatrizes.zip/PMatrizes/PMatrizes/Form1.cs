﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º número", "Entrada de Dados"); // O primeiro item do input box é a msg e o segundo é o "título da caixa"
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor Inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = String.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };
            Lista.Remove("Otávio");
            string auxiliar = "";
            foreach (string nome in Lista)
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double media = 0;
            string saida = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (!(double.TryParse(auxiliar, out notas[i, j])) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Dados Inválidos!");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                saida += $"Aluno: {i + 1} - Média: {(media / 3).ToString("N2")} \n";
                media = 0;
            }
            MessageBox.Show(saida);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx4>().Count() > 0)
            {
                Application.OpenForms["frmEx4"].BringToFront();
            }
            else
            {
                frmEx4 frm4 = new frmEx4();
                frm4.Show();
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmEx5>().Count() > 0)
            {
                Application.OpenForms["frmEx5"].BringToFront();
            }
            else
            {
                frmEx5 frm5 = new frmEx5();
                frm5.Show();
            }
        }
    }
}
