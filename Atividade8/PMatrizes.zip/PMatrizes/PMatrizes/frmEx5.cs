﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmEx5 : Form
    {
        public frmEx5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[5, 10];
            string[] gabarito = new string[] { "E", "D", "C", "B", "A", "A", "B", "C", "D", "E" };

            for (int a = 0; a < 5; a++)
            {
                for (int r = 0; r < 10; r++)
                {
                    respostas[a, r] = Interaction.InputBox($"Digite a resposta da questão {r + 1} do {a + 1}º aluno ", "Entrada de Dados");

                    if (!(respostas[a, r].ToUpper() == "A" || respostas[a, r].ToUpper() == "B" || respostas[a, r].ToUpper() == "C" || respostas[a, r].ToUpper() == "D" || respostas[a, r].ToUpper() == "E"))
                    {
                        MessageBox.Show("Dados Inválidos!");
                        r--;
                    }
                    else
                    {
                        if (respostas[a, r].ToUpper() == gabarito[r])
                        {
                            lstboxGabarito.Items.Add($"O aluno {a + 1} acertou a questão {r + 1} - Era {gabarito[r]} e escolheu {respostas[a, r].ToUpper()}");
                        }
                        else
                        {
                            lstboxGabarito.Items.Add($"O aluno {a + 1} errou a questão {r + 1} - Era {gabarito[r]} e escolheu {respostas[a, r].ToUpper()}");
                        }
                    }
                }
                lstboxGabarito.Items.Add("\n");
            }
        }
    }
}
