﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmEx4 : Form
    {
        public frmEx4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] listaNomes = new string[10];
            int[] qntdCaracter = new int[10];

            for (int i = 0; i < listaNomes.Length; i++)
            {
                listaNomes[i] = Interaction.InputBox($"Digite o {i + 1}º nome", "Entrada de Dados");
                qntdCaracter[i] = 0;

                foreach (char n in listaNomes[i])
                {
                    if (char.IsLetter(n))
                    {
                        qntdCaracter[i]++;
                    }
                }

                if (qntdCaracter[i] <= 0)
                {
                    MessageBox.Show("Nome Inválido!");
                    i--;
                }
                else
                {
                
                   lstboxNomes.Items.Add($"O nome {listaNomes[i]} tem {qntdCaracter[i]} caracteres");
                    
                }
            }
        }
    }
}
